import datetime
import json
import os
import random
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from re import search
from selenium.webdriver.support.ui import Select


s=Service(r'/Users/macbookpro/Documents/Driver/chromedriver')
driver = webdriver.Chrome(service=s)

#Getting Data from Json
dir_path = os.path.dirname(os.path.realpath(__file__))
f = open(dir_path + '/' + 'DataFile.json')
data = json.load(f)

#Save Order ID
def Save_To_File(Update, Type):
    file = open(Type, "w")
    file.write(Update)
    file.close()

#Explicit Wait
Exwait = WebDriverWait(driver, 30)

#How Much
XForLoop = 10


Store = "UAE"
def test_AssignWaves():
    Code = "7704"
    driver.get("https://sssuat.sandbox.servicepoint.fluentretail.com/#/pickandpack")

    #Login
    Exwait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/div/div/div/div/div/div/div/div/div/form/div[1]/input"))).send_keys("USR_"+Code)
    Exwait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/div/div/div/div/div/div/div/div/div/form/div[2]/input"))).send_keys("PWD_"+Code)
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/div/div/div/div/div/div/div/div/div/form/p/button/span"))))

    menu = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Menu"])))
    action = ActionChains(driver)
    action.move_to_element(menu).click().perform()
    time.sleep(2)
    wave = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Select"])))
    wave.click()

    #if Exwait.until(EC.visibility_of_element_located((By.XPATH, data["Service_Point"]["Wave_Button"]))).is_enabled():
    while Exwait.until(EC.visibility_of_element_located((By.XPATH, data["Service_Point"]["Wave_Button"]))).is_enabled():
        Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Button"]))).click()
        time.sleep(5)
        driver.get("https://sssuat.sandbox.servicepoint.fluentretail.com/#/pickandpack")
        menu = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Menu"])))
        action.move_to_element(menu).click().perform()
        time.sleep(2)
        wave = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Select"])))
        wave.click()
        time.sleep(2)
    #else:
        #print("None")
    print("Finish")

def test_Login():
    driver.get(data["Sites"]["SSS_" + Store])
    driver.maximize_window()

    # Select UAE
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Select_Country_UAE"]))))
    # Login User Icon
    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Login_User_Icon"]))))

    # Login Form
    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Login_Form"]))))

    # Fill Details and Login
    time.sleep(3)
    Exwait.until(EC.visibility_of_element_located((By.NAME, data["SSS"]["Login_Email"]))).send_keys(data["LoginCreds"]["SSS_" + Store]["UserEmail"])
    time.sleep(1)
    Exwait.until(EC.visibility_of_element_located((By.NAME, data["SSS"]["Login_Password"]))).send_keys(data["LoginCreds"]["SSS_" + Store]["UserPassword"])
    # Login Button
    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Login_Button"]))))

    #Accept Cookies
    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Accept_Cookies"]))))


def test_PlaceOrder_REG_COD():

    test_Login()

    #Update Payment Method
    Save_To_File("COD", "Payment_Method")

    Quantity = "(3)"
    n = 1
    for i in range(n):
        # Search SKU
        time.sleep(5)
        Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Search_Bar"]))).send_keys(data["SKU"]["SSS_" + Store]["3"])
        Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Search_Bar"]))).send_keys(Keys.RETURN)

        #Select Quantity
        Menu = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Quantity_Select"])))
        action = ActionChains(driver)
        action.move_to_element(Menu).click().perform()
        time.sleep(2)
        Select = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Quantity_Option"] + Quantity)))
        Select.click()

        # Add to Bag
        driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Add_To_Bag"]))))
        # Checkout Securely
        driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Checkout"]))))

        # Continue to Payment
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Continue_To_Payment"]))))

        time.sleep(10)
        # Select COD
        driver.execute_script("arguments[0].click();", Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Select_COD"]))))

        # Review Order
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Review_Order"]))))

        # Confirm and Pay
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Confirm_And_Pay"]))))

        #Go Home Again
        #Exwait.until(EC.text_to_be_present_in_element((By.CSS_SELECTOR, "body > div.page.page--checkout.js-checkout-page > main > section:nth-child(3) > div > div > div > h3 > span.summary-section-label.order-number-label"), "Your Order Number:"))
        Order_ID = Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Order_ID"]))).text
        Save_To_File(Order_ID, "Order_ID")
        driver.get(data["Sites"]["SSS_" + Store])
        i = i + 1

    #driver.close()

def test_PlaceOrder_REG_CC():

    test_Login()

    # Update Payment Method
    Save_To_File("CC", "Payment_Method")

    Quantity = "(3)"
    n = 1
    for i in range(n):
        # Search SKU
        time.sleep(5)
        Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Search_Bar"]))).send_keys(data["SKU"]["SSS_" + Store]["3"])
        Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Search_Bar"]))).send_keys(Keys.RETURN)

        # Select Quantity
        Menu = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Quantity_Select"])))
        action = ActionChains(driver)
        action.move_to_element(Menu).click().perform()
        time.sleep(2)
        Select = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Quantity_Option"] + Quantity)))
        Select.click()

        # Add to Bag
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Add_To_Bag"]))))
        # Checkout Securely
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Checkout"]))))

        # Continue to Payment
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Continue_To_Payment"]))))

        time.sleep(10)
        # Select CC
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Select_CC"]))))
        time.sleep(5)

        # Select First Card
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Select_First_Card"]))))

        time.sleep(2)

        #Enter CVV
        Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["CVV"]))).send_keys("123")

        #Review Order
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Review_Order"]))))

        #Confirm and Pay
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Confirm_And_Pay"]))))

        #3D Verification
        Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["CC_3D"]))).send_keys("12345")
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["CC_3D_Submit"]))))

        # Go Home Again
        # Exwait.until(EC.text_to_be_present_in_element((By.CSS_SELECTOR, "body > div.page.page--checkout.js-checkout-page > main > section:nth-child(3) > div > div > div > h3 > span.summary-section-label.order-number-label"), "Your Order Number:"))
        Order_ID = Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Order_ID"]))).text
        Save_To_File(Order_ID, "Order_ID")
        driver.get(data["Sites"]["SSS_" + Store])
        i = i + 1

    #driver.close()

def test_PlaceOrder_REG_Tabby():

    test_Login()
    #Update Payment Method
    Save_To_File("Tabby", "Payment_Method")

    Quantity = "(3)"
    n = 1
    for i in range(n):
        # Search SKU
        time.sleep(5)
        Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Search_Bar"]))).send_keys(data["SKU"]["SSS_" + Store]["3"])
        Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Search_Bar"]))).send_keys(Keys.RETURN)

        # Select Quantity
        Menu = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Quantity_Select"])))
        action = ActionChains(driver)
        action.move_to_element(Menu).click().perform()
        time.sleep(2)
        Select = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Quantity_Option"] + Quantity)))
        Select.click()

        # Add to Bag
        driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Add_To_Bag"]))))
        # Checkout Securely
        driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Checkout"]))))

        # Continue to Payment
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Continue_To_Payment"]))))

        # Select Tabby
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Select_Tabby"]))))

        # Select Installment
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Select_Installment"]))))

        # Review Order
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.XPATH, data["SSS"]["Review_Order"]))))

        # Confirm and Pay
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.XPATH,data["SSS"]["Confirm_And_Pay"]))))

        driver.switch_to.frame(Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Switch_Tabby_Frame"]))))
        #Tabby Starts
        Phone = Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Tabby_Phone"])))
        Email = Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Tabby_Email"])))

        Phone.clear()
        time.sleep(1)
        Phone.send_keys(data["SSS_Payment_Creds"]["Tabby"]["Phone"])

        time.sleep(2)

        Email.clear()
        time.sleep(1)
        Email.send_keys(data["SSS_Payment_Creds"]["Tabby"]["Email"])

        #Proceed
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, ))))

        #OTP
        Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Tabby_OTP1"]))).send_keys("8")
        Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Tabby_OTP2"]))).send_keys("8")
        Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Tabby_OTP3"]))).send_keys("8")
        Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Tabby_OTP4"]))).send_keys("8")

        #Upload Image
        Exwait.until(EC.visibility_of_element_located((By.XPATH, "/html/body/div[1]/div/div[2]/div[3]/input"))).send_keys("/Users/macbookpro/PycharmProjects/TrippleS/image.png")
        #Buy Now
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "#embed-tabby-checkout > div > div.Layout__page--b941b > div.Layout__belt--d67b1 > button.Button__container--f2006.ScanConfirm__callToAction--cbd42.Button__primary--df1ff"))))

        # Go Home Again
        # Exwait.until(EC.text_to_be_present_in_element((By.CSS_SELECTOR, "body > div.page.page--checkout.js-checkout-page > main > section:nth-child(3) > div > div > div > h3 > span.summary-section-label.order-number-label"), "Your Order Number:"))
        Order_ID = Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Order_ID"]))).text
        Save_To_File(Order_ID, "Order_ID")
        driver.get(data["Sites"]["SSS_" + Store])
        i = i + 1

    driver.close()

def test_PlaceOrder_REG_eWallet():
    eWallet_ID = data["SSS_Payment_Creds"]["UAE_eWallet"]["ID"]
    eWallet_Pass = data["SSS_Payment_Creds"]["UAE_eWallet"]["Pass"]

    test_Login()

    # Update Payment Method
    Save_To_File("eWallet", "Payment_Method")

    Quantity = "(3)"
    n = 1
    for i in range(n):
        # Search SKU
        time.sleep(5)
        Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Search_Bar"]))).send_keys(data["SKU"]["SSS_" + Store]["3"])
        Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Search_Bar"]))).send_keys(Keys.RETURN)

        # Select Quantity
        Menu = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Quantity_Select"])))
        action = ActionChains(driver)
        action.move_to_element(Menu).click().perform()
        time.sleep(2)
        Select = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Quantity_Option"] + Quantity)))
        Select.click()

        # Add to Bag
        driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Add_To_Bag"]))))
        # Checkout Securely
        driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Checkout"]))))

        # Continue to Payment
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Continue_To_Payment"]))))

        # Select eWallet
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Select_eWallet"]))))

        # Add eWallet
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Add_eWallet"]))))

        #Enter Creds
        Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["eWallet_Number"]))).send_keys(eWallet_ID)
        Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["eWallet_Pin"]))).send_keys(eWallet_Pass)

        #Submit
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["eWallet_Submit"]))))

        time.sleep(4)

        # Review Order
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Review_Order"]))))

        # Confirm and Pay
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Confirm_And_Pay"]))))

        #Go Home Again
        #Exwait.until(EC.text_to_be_present_in_element((By.CSS_SELECTOR, "body > div.page.page--checkout.js-checkout-page > main > section:nth-child(3) > div > div > div > h3 > span.summary-section-label.order-number-label"), "Your Order Number:"))
        Order_ID = Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Order_ID"]))).text
        Save_To_File(Order_ID, "Order_ID")
        driver.get(data["Sites"]["SSS_" + Store])
        i = i + 1

    driver.close()

def test_Register():
    driver.get(data["Sites"]["SSS_"+Store])
    driver.maximize_window()

    # Select UAE
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Select_Country_UAE"]))))

    #Login User Icon
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Select_User_Icon"]))))

    #Register Form
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Register_Form"]))))

    #Fill Details and Login
    time.sleep(3)
    Exwait.until(EC.element_to_be_clickable((By.NAME, data["SSS"]["Register_Email"]))).send_keys(data["RegisterationData"]["SSS_"+Store]["Email"])
    Exwait.until(EC.element_to_be_clickable((By.NAME, data["SSS"]["Register_First_Name"]))).send_keys(data["RegisterationData"]["SSS_"+Store]["FirstName"])
    Exwait.until(EC.element_to_be_clickable((By.NAME, data["SSS"]["Register_Last_Name"]))).send_keys(data["RegisterationData"]["SSS_"+Store]["LastName"])
    Exwait.until(EC.element_to_be_clickable((By.NAME, data["SSS"]["Register_Password"]))).send_keys(data["RegisterationData"]["SSS_"+Store]["Password1"])
    Exwait.until(EC.element_to_be_clickable((By.NAME, data["SSS"]["Register_Confirm_Password"]))).send_keys(data["RegisterationData"]["SSS_"+Store]["Password2"])
    driver.execute_script("arguments[0].click();", Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Register_Male"]))))
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Register_Button"]))))

    MSG = Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Register_MSG"]))).text
    assert MSG == "Thanks for signing up, "+data['RegisterationData']['SSS_'+Store]['FirstName']+"!"

def test_AddToFav():

    test_Login()
    time.sleep(5)

    Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Search_Bar"]))).send_keys(data["SKU"]["SSS_" + Store]["1"])
    Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Search_Bar"]))).send_keys(Keys.RETURN)

    # Add to Fav
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Add_To_Fav"]))))

    #Copy Product Title
    Title1 = Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Product_Title1"]))).text

    # Go to Fav
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Go_To_Fav"]))))

    Title2 = Exwait.until(EC.visibility_of_element_located((By.XPATH, data["SSS"]["Product_Title2"]))).text

    assert Title1 == Title2
    driver.close()

def test_CreateReturn():

    test_Login()
    time.sleep(5)

    #Get Order ID
    file = open("Order_ID", "r")
    Order_ID = file.read()

    driver.get(data["SSS"]["Return_URL_UAE"] + Order_ID)

    #Create Request
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.XPATH, data["SSS"]["Create_Return_Request"]))))
    # Continue
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Return_Continue"]))))

    #Fill Details
    QuanityMenu = Exwait.until(EC.element_to_be_clickable(
        (By.CSS_SELECTOR, "#qty-0")))
    action = ActionChains(driver)
    action.move_to_element(QuanityMenu).click().perform()
    time.sleep(2)
    Quanity = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Return_Quantity"])))
    Quanity.click()

    #Reason
    ReasonMenu = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "#reason-0")))
    action = ActionChains(driver)
    action.move_to_element(ReasonMenu).click().perform()
    time.sleep(2)
    Reason = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Return_Reason"])))
    Reason.click()

    #Resolution
    ResolutionMenu = Exwait.until(EC.element_to_be_clickable(
        (By.CSS_SELECTOR, "#resolution-0")))
    action = ActionChains(driver)
    action.move_to_element(ResolutionMenu).click().perform()
    time.sleep(2)
    Resolution = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Return_Resolution"])))
    Resolution.click()

    time.sleep(5)

    #Pickup Address
    Button = Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Return_Pickup_Address"])))
    driver.execute_script('arguments[0].removeAttribute("disabled");', Button)
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Return_Pickup_Address"]))))

    #Select Address
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Return_Select_Address"]))))

    #Proceed
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Return_Proceed"]))))

    #Check Payment Method
    file = open("Payment_Method", "r")
    Payment_Method = file.read()

    if Payment_Method == "CC":
        #Where To Refund
        #driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Refund_To_eWallet"]))))
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Refund_To_CC"]))))

    #Submit
    #driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Return_Submit"]))))

    MSG = Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Return_MSG"]))).text
    Return_Order_ID = Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Return_Order_ID"]))).text

    Save_To_File(Return_Order_ID, "Return_Order_ID")

    assert MSG == "Return request has been received and will be reviewed. You will be notified once your request has been accepted."

    driver.close()

def test_CreateExchange():

    test_Login()
    time.sleep(5)

    driver.execute_script(data["SSS"]["Return_URL_UAE"])

    driver.switch_to.window(driver.window_handles[1])

    #Create Request
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.XPATH, data["SSS"]["Create_Return_Request"]))))
    # Continue
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Return_Continue"]))))

    #Fill Details
    QuanityMenu = Exwait.until(EC.element_to_be_clickable(
        (By.CSS_SELECTOR, "#qty-0")))
    action = ActionChains(driver)
    action.move_to_element(QuanityMenu).click().perform()
    time.sleep(2)
    Quanity = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Return_Quantity"])))
    Quanity.click()

    #Reason
    ReasonMenu = Exwait.until(EC.element_to_be_clickable(
        (By.CSS_SELECTOR, "#reason-0")))
    action = ActionChains(driver)
    action.move_to_element(ReasonMenu).click().perform()
    time.sleep(2)
    Reason = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Return_Reason"])))
    Reason.click()

    #Resolution
    ResolutionMenu = Exwait.until(EC.element_to_be_clickable(
        (By.CSS_SELECTOR, "#resolution-0")))
    action = ActionChains(driver)
    action.move_to_element(ResolutionMenu).click().perform()
    time.sleep(2)
    Resolution = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Exchange_Resolution"])))
    Resolution.click()

    EnableSizeButton = Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, "#maincontent > div > div.container.container--account > div > section > div.account__main-body > div > div > section.account__request-items.js-request-item > div.account__order-summary > div > div > div > div.order-product-summary-item.js-product-summary-block > form > div.account__request-form-fields > fieldset:nth-child(3) > div > div.col--fixed.js-reason-other-field.d-none")))
    driver.execute_script('arguments[0].removeAttribute("d-none");', EnableSizeButton)

    #Size
    SizeMenu = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "#size-0")))
    action = ActionChains(driver)
    action.move_to_element(SizeMenu).click().perform()
    time.sleep(2)
    Size = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Exchange_Size"])))
    Size.click()

    time.sleep(5)

    #Pickup Address
    Button = Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Return_Pickup_Address"])))
    driver.execute_script('arguments[0].removeAttribute("disabled");', Button)
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Return_Pickup_Address"]))))

    #Select 1st Address
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Return_Select_Address"]))))

    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Return_Proceed"]))))

    #Submit
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Return_Submit"]))))

    MSG = Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["SSS"]["Exchange_MSG"]))).text

    assert MSG == "Return request has been received and will be reviewed. You will be notified once your request has been accepted."

    driver.close()

def test_Add_Address():

    test_Login()

    #Go to Address Book
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Go_To_Address_Book"]))))

    #Add New Address
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Add_Address"]))))

    #Address Line 1
    Exwait.until(EC.visibility_of_element_located((By.NAME, data["SSS"]["Address_Line1"]))).send_keys(data["NewAddress"]["SSS_"+Store]["AddressLine1"])
    #Region
    RegionMenu = Exwait.until(EC.element_to_be_clickable(
        (By.CSS_SELECTOR, "#city")))
    action = ActionChains(driver)
    action.move_to_element(RegionMenu).click().perform()
    time.sleep(2)
    Region = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Region"])))
    Region.click()

    #Area
    AreaMenu = Exwait.until(EC.element_to_be_clickable(
        (By.CSS_SELECTOR, "#area")))
    action = ActionChains(driver)
    action.move_to_element(AreaMenu).click().perform()
    time.sleep(2)
    Area = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Area"])))
    Area.click()

    #AddressID
    Exwait.until(EC.visibility_of_element_located((By.NAME, data["SSS"]["Address_ID"]))).send_keys(data["NewAddress"]["SSS_"+Store]["Address"])

    #Save
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Save_Address"]))))

    driver.close()

def test_Collect_SSS_Points():

    test_Login()
    time.sleep(5)
    driver.get(data["SSS"]["Order_Page_URL"] + "DEVA070829")
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Accept_Cookies"]))))
    driver.refresh()

    #Check If Already Collected
    Check = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Verify_Label"]))).text

    if "on" in Check:
        print(("Already Collected: " + Check))
        assert 1 == 0

    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Collect"]))))
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.XPATH, data["SSS"]["Checkbox"]))))
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Collect_Button"]))))
    time.sleep(5)
    driver.refresh()

    Check = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Verify_Label"]))).text

    if len(Check) < 33:
        assert 1 == 0
    else:
        assert 1 == 1

def test_Add_Payment_Method_CC():

    test_Login()

    time.sleep(5)

    driver.get(data["SSS"]["Add_Payment_Method_URL"])

    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Add_CC_Method"]))))

    #Fill Details
    Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Card_Number"]))).send_keys(data["SSS_Payment_Creds"]["CC"]["Card_Number"])
    Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Card_Name"]))).send_keys(data["SSS_Payment_Creds"]["CC"]["Card_Name"])

    #Expiry Month
    Menu = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Expiry_Month_Select"])))
    action = ActionChains(driver)
    action.move_to_element(Menu).click().perform()
    time.sleep(2)
    Select = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Expiry_Month_Option"])))
    Select.click()

    #Expiry Year
    Menu = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Expiry_Year_Select"])))
    action = ActionChains(driver)
    action.move_to_element(Menu).click().perform()
    time.sleep(2)
    Select = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Expiry_Year_Option"])))
    Select.click()

    Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Card_CVV"]))).send_keys(data["SSS_Payment_Creds"]["CC"]["CVV"])

    OLd_URL = driver.current_url

    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Card_Submit"]))))

    time.sleep(5)

    assert driver.current_url != OLd_URL

def test_Make_Cart_Empty():

    test_Login()

    Quantity = "(5)"
    n = 1
    for i in range(n):
        # Search SKU
        time.sleep(5)
        Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Search_Bar"]))).send_keys(data["SKU"]["SSS_" + Store]["3"])
        Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Search_Bar"]))).send_keys(Keys.RETURN)

        # Select Quantity
        Menu = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Quantity_Select"])))
        action = ActionChains(driver)
        action.move_to_element(Menu).click().perform()
        time.sleep(2)
        Select = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Quantity_Option"] + Quantity)))
        Select.click()

        # Add to Bag
        driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Add_To_Bag"]))))
        # Checkout Securely
        driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.XPATH, data["SSS"]["View_Bag"]))))

        #Delete Items Button
        driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Delete_Items_Button"]))))

        time.sleep(5)

        Remaining_Items = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["SSS"]["Remaining_Items"]))).text

        assert Remaining_Items == "0 Item(s)"



def test_Add_Payment_Method_eWallet():

    test_Login()

    time.sleep(5)

    driver.get(data["SSS"]["Add_Payment_Method_URL"])

    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Add_eWallet_Method"]))))
    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["Add_SSS_eWallet"]))))

    #Fill Details
    Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["eWallet_Card_Number"]))).send_keys(data["SSS_Payment_Creds"]["UAE_eWallet"]["ID"])
    Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["eWallet_Card_Pin"]))).send_keys(data["SSS_Payment_Creds"]["UAE_eWallet"]["Pass"])

    OLd_URL = driver.current_url

    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["SSS"]["eWallet_Submit_Button"]))))

    time.sleep(5)

    assert driver.current_url != OLd_URL


#FLUENT CONSOLE

def test_Fluent_Login():
    driver.get(data["Fluent"]["URL"])

    # Login
    Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Fluent"]["User_UAE"]))).send_keys(data["Fluent"]["User_UAE_Value"])
    Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Fluent"]["Password"]))).send_keys(data["Fluent"]["Password_Value"])
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Fluent"]["Login_Button"]))))
    time.sleep(5)
    driver.refresh()

def test_Get_Fulfilment_Loc_Fluent():

    test_Fluent_Login()

    #Get Order ID
    file = open("Order_ID", "r")
    Order_ID = file.read()

    #Search
    Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Fluent"]["Search_Bar"]))).send_keys("ref:" + Order_ID)
    Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Fluent"]["Search_Bar"]))).send_keys(Keys.RETURN)
    time.sleep(5)

    #Click ID and Go to Fulfilments
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Fluent"]["Click_Order_ID"]))))
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Fluent"]["Go_to_Fulfilments"]))))
    Wave_Status = Exwait.until(EC.presence_of_element_located((By.XPATH, data["Fluent"]["Wave_Status"]))).text

    if Wave_Status == "ASSIGNED":
        Fulfilment_Loc = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Fluent"]["Fulfilment_Loc"]))).text
        Destination_Loc = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Fluent"]["Destination_Loc"]))).text
        assert Fulfilment_Loc == Destination_Loc
        return Fulfilment_Loc
    else:
        while Wave_Status != "AWAITING_WAVE":
            driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Fluent"]["Refresh"]))))
            #driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Fluent"]["Go_to_Fulfilments"]))))
            Wave_Status = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Fluent"]["Wave_Status"]))).text

        Fulfilment_Loc = Exwait.until(EC.visibility_of_element_located((By.XPATH, data["Fluent"]["Fulfilment_Loc"]))).text
        Destination_Loc = Exwait.until(EC.visibility_of_element_located((By.XPATH, data["Fluent"]["Destination_Loc"]))).text
        assert Fulfilment_Loc == Destination_Loc
        return Fulfilment_Loc

def test_Get_Wave_ID_Fluent():

    #test_Fluent_Login()

    driver.get(data["Fluent"]["URL"])

    #Get Order ID
    file = open("Order_ID", "r")
    Order_ID = file.read()

    #Search
    Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Fluent"]["Search_Bar"]))).send_keys("ref:" + Order_ID)
    Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Fluent"]["Search_Bar"]))).send_keys(Keys.RETURN)
    time.sleep(5)

    #Click ID and Go to Fulfilments
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Fluent"]["Click_Order_ID"]))))
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Fluent"]["Go_to_Fulfilments"]))))

    time.sleep(5)
    Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Fluent"]["Click_Ful_ID"]))).click()
    time.sleep(3)
    Wave_ID = Exwait.until(EC.presence_of_element_located((By.XPATH, data["Fluent"]["Wave_ID"]))).text
    print("111111" + Wave_ID)

    return Wave_ID

def test_Check_Stock():

    test_Fluent_Login()

    time.sleep(10)

    driver.get(data["Fluent"]["Check_Stock_URL"] + "193658648844")

    #Select 100
    Menu = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Fluent"]["Select_100_Menu"])))
    action = ActionChains(driver)
    action.move_to_element(Menu).click().perform()
    time.sleep(2)
    Select = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Fluent"]["Select_100_Option"])))
    Select.click()

    time.sleep(3)

    CountRows = driver.find_elements(By.XPATH, "//tr/td[@class=' col-priority-normal '][5]/span")

    print("/n")
    for i in range(int(len(CountRows))):
        i = i + 1
        Store = Exwait.until(EC.visibility_of_element_located((By.XPATH, "//tr[" + str(i) + "]/td[@class=' col-priority-normal '][5]/span"))).text
        Stock = Exwait.until(EC.visibility_of_element_located((By.XPATH, "//tr[" + str(i) + "]/td[@class=' col-priority-normal '][6]/span"))).text

        if Stock != '0':
            print("************************")
        else:
            print(Store + " = " + Stock)


#SERVICE POINT

def test_ServicePoint_Login():

    Code = test_Get_Fulfilment_Loc_Fluent()
    XCode = Code
    driver.get(data["Service_Point"]["URL"])
    # Login
    Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["User"]))).send_keys("USR_" + XCode)
    Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Password"]))).send_keys("PWD_" + XCode)
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Login_Button"]))))

def test_Pack_Ship():

    Wave_ID = test_Get_Wave_ID_Fluent()
    #test_ServicePoint_Login()
    # Login
    driver.get(data["Service_Point"]["URL"])
    #Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["User"]))).send_keys("USR_" + test_Get_Fulfilment_Loc_Fluent().Fulfilment_Loc)
    #Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Password"]))).send_keys("PWD_" + test_Get_Fulfilment_Loc_Fluent().Fulfilment_Loc)
    #driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Login_Button"]))))
    print(Wave_ID)
    driver.get("https://sssuat.sandbox.servicepoint.fluentretail.com/#/pickandpack/" + Wave_ID + "/PICK")

    time.sleep(2)
    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Service_Point"]["Confirm_Item1"]))))
    time.sleep(2)
    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Service_Point"]["Confirm_Item2"]))))

    while len(driver.current_url) < 77:
        Done = Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["Service_Point"]["Label_Title"]))).text
        print(Done)
        if Done == "Wave " + Wave_ID + ": Labels":
            break
        driver.execute_script("arguments[0].click();",Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["Service_Point"]["Book_Courier1"]))))
        driver.execute_script("arguments[0].click();",Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["Service_Point"]["Book_Courier2"]))))
        time.sleep(4)


    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Service_Point"]["Download_Label"]))))

    time.sleep(8)
    driver.switch_to.window(driver.window_handles[0])

    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Service_Point"]["Courier_Collect"]))))
    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Service_Point"]["Courier_CheckAll"]))))
    Check_Button = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Service_Point"]["Collect_Button"])))
    driver.execute_script('arguments[0].removeAttribute("disabled");', Check_Button)
    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Service_Point"]["Collect_Button"]))))

def test_Shipsy_Login():
    driver.get(data["Shipsy"]["URL"])

    Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Shipsy"]["User"]))).send_keys("gmggroupadmin")
    Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Shipsy"]["Password"]))).send_keys("gmggroup123")
    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Shipsy"]["Login"]))))

def test_Shipsy_Delivery():

    test_Shipsy_Login()

    time.sleep(5)

    driver.get(data["Shipsy"]["Delivery_URL"])

    #Get Order ID
    file = open("Order_ID", "r")
    Order_ID = file.read()

    Menu = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Shipsy"]["Dropdown"])))
    action = ActionChains(driver)
    action.move_to_element(Menu).click().perform()
    time.sleep(2)
    Select = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Shipsy"]["Select_By_Customer_Reference"])))
    Select.click()

    Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Shipsy"]["Search_Bar"]))).send_keys(Order_ID)
    Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Shipsy"]["Search_Bar"]))).send_keys(Keys.RETURN)

    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Shipsy"]["CheckBox"]))))


    Menu = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Shipsy"]["Action"])))
    action = ActionChains(driver)
    time.sleep(5)
    action.move_to_element(Menu).perform()
    Select = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Shipsy"]["Mark_Delivered"])))
    Select.click()

    driver.execute_script("arguments[0].click();",Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Shipsy"]["Ok"]))))

def test_Verify_If_Delivered():

    test_Fluent_Login()

    #driver.get(data["Fluent"]["URL"])

    #Get Order ID
    file = open("Order_ID", "r")
    Order_ID = file.read()

    # Search
    Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Fluent"]["Search_Bar"]))).send_keys("ref:" + Order_ID)
    Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Fluent"]["Search_Bar"]))).send_keys(Keys.RETURN)
    time.sleep(5)

    Order_Status = Exwait.until(EC.presence_of_element_located((By.XPATH, data["Fluent"]["Order_Status"]))).text

    while Exwait.until(EC.presence_of_element_located((By.XPATH, data["Fluent"]["Order_Status"]))).text != "COMPLETE":
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Fluent"]["Refresh"]))))

    assert Order_Status == "COMPLETE"

def test_Shipsy_Return():

    #test_CreateReturn()
    test_Verify_If_Delivered()
    test_Shipsy_Login()

    # Get Order ID
    file = open("Return_Order_ID", "r")
    Return_Order_ID = file.read()

    #Select Test Hub
    Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Shipsy"]["Select_Hub"]))).send_keys("TestHub")
    time.sleep(3)
    driver.execute_script("arguments[0].click();", Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["Shipsy"]["Select_Test_Hub"]))))

    #Go to Unplanned Tab
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Shipsy"]["Unplanned"]))))

    # Search By Customer Reference
    driver.execute_script("arguments[0].click();", Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["Shipsy"]["More_Filters"]))))
    driver.find_element(By.XPATH, data["Shipsy"]["Search_By_Customer_Reference"]).send_keys(Return_Order_ID)
    driver.find_element(By.XPATH, data["Shipsy"]["Search_By_Customer_Reference"]).send_keys(Keys.RETURN)
    driver.execute_script("arguments[0].click();", Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, data["Shipsy"]["Apply_Button"]))))

    time.sleep(5)
    driver.execute_script("arguments[0].click();", Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, "#rc-tabs-0-panel-logistics_express_unplanned > div > div.n-tableContainer-0-3-155 > div > div.t-tableParent-0-3-213 > div > div > div > div > div > div.ant-table-body > table > tbody > tr.ant-table-row.ant-table-row-level-0 > td.ant-table-cell.ant-table-selection-column.ant-table-cell-fix-left > label > span"))))

    #Create Route
    Menu = Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, data["Shipsy"]["Create_Route"])))
    action = ActionChains(driver)
    action.move_to_element(Menu).click().perform()
    time.sleep(2)
    Select = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Shipsy"]["Selected"])))
    Select.click()

    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Shipsy"]["Yes_Button"]))))

def test_Complete_Order_Processing_COD():

    test_PlaceOrder_REG_COD()
    #test_PlaceOrder_REG_CC()
    #test_PlaceOrder_REG_eWallet()
    test_ServicePoint_Login()

    menu = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Menu"])))
    action = ActionChains(driver)
    action.move_to_element(menu).click().perform()
    time.sleep(2)
    wave = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Select"])))
    wave.click()

    #if Exwait.until(EC.visibility_of_element_located((By.XPATH, data["Service_Point"]["Wave_Button"]))).is_enabled():
    while Exwait.until(EC.visibility_of_element_located((By.XPATH, data["Service_Point"]["Wave_Button"]))).is_enabled():
        Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Button"]))).click()
        time.sleep(5)
        driver.get("https://sssuat.sandbox.servicepoint.fluentretail.com/#/pickandpack")
        menu = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Menu"])))
        action.move_to_element(menu).click().perform()
        time.sleep(2)
        wave = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Select"])))
        wave.click()
        time.sleep(2)
    #else:
        #test_Pack_Ship()
    test_Pack_Ship()
    test_Shipsy_Delivery()

def test_Complete_Order_Processing_CC():

    #test_PlaceOrder_REG_COD()
    test_PlaceOrder_REG_CC()
    #test_PlaceOrder_REG_eWallet()
    test_ServicePoint_Login()

    menu = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Menu"])))
    action = ActionChains(driver)
    action.move_to_element(menu).click().perform()
    time.sleep(2)
    wave = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Select"])))
    wave.click()

    #if Exwait.until(EC.visibility_of_element_located((By.XPATH, data["Service_Point"]["Wave_Button"]))).is_enabled():
    while Exwait.until(EC.visibility_of_element_located((By.XPATH, data["Service_Point"]["Wave_Button"]))).is_enabled():
        Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Button"]))).click()
        time.sleep(5)
        driver.get("https://sssuat.sandbox.servicepoint.fluentretail.com/#/pickandpack")
        menu = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Menu"])))
        action.move_to_element(menu).click().perform()
        time.sleep(2)
        wave = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Select"])))
        wave.click()
        time.sleep(2)
    #else:
        #test_Pack_Ship()
    test_Pack_Ship()
    test_Shipsy_Delivery()

def test_Complete_Order_Processing_eWallet():

    #test_PlaceOrder_REG_COD()
    #test_PlaceOrder_REG_CC()
    test_PlaceOrder_REG_eWallet()
    test_ServicePoint_Login()

    menu = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Menu"])))
    action = ActionChains(driver)
    action.move_to_element(menu).click().perform()
    time.sleep(2)
    wave = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Select"])))
    wave.click()

    #if Exwait.until(EC.visibility_of_element_located((By.XPATH, data["Service_Point"]["Wave_Button"]))).is_enabled():
    while Exwait.until(EC.visibility_of_element_located((By.XPATH, data["Service_Point"]["Wave_Button"]))).is_enabled():
        Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Button"]))).click()
        time.sleep(5)
        driver.get("https://sssuat.sandbox.servicepoint.fluentretail.com/#/pickandpack")
        menu = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Menu"])))
        action.move_to_element(menu).click().perform()
        time.sleep(2)
        wave = Exwait.until(EC.element_to_be_clickable((By.XPATH, data["Service_Point"]["Wave_Select"])))
        wave.click()
        time.sleep(2)
    #else:
        #test_Pack_Ship()
    test_Pack_Ship()
    test_Shipsy_Delivery()
