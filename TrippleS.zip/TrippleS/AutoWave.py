import datetime
import json
import os
import random
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from tkinter.messagebox import showinfo
from selenium.webdriver.support.ui import Select
import tkinter as tk
from tkinter import *
from tkinter.messagebox import showinfo
from re import search


#root window
root = tk.Tk()

# Make interactable
root.grab_release()

root.geometry('400x200')
root.resizable(False, False)
root.title('Auto Wave Assign')


s=Service(r'/Users/macbookpro/Documents/Driver/chromedriver')
driver = webdriver.Chrome(service=s)

#Getting Data from Json
dir_path = os.path.dirname(os.path.realpath(__file__))
f = open(dir_path + '/' + 'DataFile.json')
data = json.load(f)

#Explicit Wait
Exwait = WebDriverWait(driver, 15)


Store = "UAE"
Code = "7704"
def AssignWaves():
    driver.get("https://sssuat.sandbox.servicepoint.fluentretail.com/#/pickandpack")

    #Login
    Exwait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/div/div/div/div/div/div/div/div/div/form/div[1]/input"))).send_keys("USR_"+Code.get())
    Exwait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/div/div/div/div/div/div/div/div/div/form/div[2]/input"))).send_keys("PWD_"+Code.get())
    driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/div/div/div/div/div/div/div/div/div/form/p/button/span"))))

    try:
        CountWaves = Exwait.until(EC.visibility_of_element_located((By.XPATH,"/html/body/div/div/div/div/div[2]/div/div[1]/div/div/div[1]/div/div/div[1]/table/tbody/tr/td[2]"))).text
    except:
        CountWaves = 0

    HowMuch = Exwait.until(EC.visibility_of_element_located((By.CSS_SELECTOR,"#content > div > div > div:nth-child(1) > div > div > div:nth-child(1) > div"))).text

    if str(HowMuch) != "0 unallocated orders":
        while int(CountWaves) > 0:
            menu = Exwait.until(EC.element_to_be_clickable((By.XPATH,"/html/body/div/div/div/div/div[2]/div/div[1]/div/div/div[1]/div/div/div[2]/form/ul/li/select")))
            action = ActionChains(driver)
            action.move_to_element(menu).click().perform()
            time.sleep(2)
            wave = Exwait.until(EC.element_to_be_clickable((By.XPATH,"/html/body/div/div/div/div/div[2]/div/div[1]/div/div/div[1]/div/div/div[2]/form/ul/li/select/option[2]")))
            wave.click()
            driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/div/div/div/div/div[2]/div/div[1]/div/div/div[1]/div/div/div[2]/button/span"))))
            time.sleep(2)
            driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "#sidebar > nav > ul > li:nth-child(1) > a"))))

            try:
                CountWaves = Exwait.until(EC.visibility_of_element_located((By.XPATH, "/html/body/div/div/div/div/div[2]/div/div[1]/div/div/div[1]/div/div/div[1]/table/tbody/tr/td[2]"))).text
            except:
                driver.execute_script("arguments[0].click();", Exwait.until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, "#sidebar > nav > ul > li:nth-child(8) > a"))))
                showinfo("Status", "No More Active Waves Found, Getting Logout")
                root.mainloop()
    else:
        time.sleep(2)
        driver.execute_script("arguments[0].click();", Exwait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "#sidebar > nav > ul > li:nth-child(8) > a"))))
        showinfo("Status", "No More Active Waves Found, Getting Logout")
        root.mainloop()

#Inputs
tk.Label(root, text = 'Enter Store Code', font=('calibre',10, 'bold')).grid(row=1, column=0, pady='10', ipady=10, ipadx=15)
Code=tk.StringVar()
tk.Entry(root,textvariable = Code, font=('calibre',10,'normal')).grid(row=1, column=1, pady='10', ipady=10, ipadx=15)

#Button
tk.Label(root, text = 'Start', font=('calibre',15, 'bold')).grid(row=2, column=0, pady='10', ipady=10, ipadx=15)
tk.Button(root, text="Auto Assign", bg="Red", fg="Red", command=AssignWaves).grid(row=2, column=1, pady='10', ipady=10, ipadx=15)

root.mainloop()